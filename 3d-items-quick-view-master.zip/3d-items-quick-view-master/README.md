3D Items Quick View
=========

A simple 3D animation for your gallery items, to make it easy for users to discover more about your products without having to leave the page.

[Article on CodyHouse](http://codyhouse.co/gem/3d-items-quick-view/)

[Demo](http://codyhouse.co/demo/3d-items-quick-view/index.html)
 
[Terms](http://codyhouse.co/terms/)
